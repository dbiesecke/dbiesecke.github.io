sleep 5s
killall conky
cd "/home/dbiesecke/.conky/foilo"
conky -c "/home/dbiesecke/.conky/foilo/conky_seamod" &
cd "/home/dbiesecke/.conky/foilo"
conky -c "/home/dbiesecke/.conky/foilo/conkyrc" &
cd "/home/dbiesecke/.conky/foilo"
conky -c "/home/dbiesecke/.conky/foilo/date" &
cd "/home/dbiesecke/.conky/foilo"
conky -c "/home/dbiesecke/.conky/foilo/red" &
cd "/home/dbiesecke/.conky/foilo"
conky -c "/home/dbiesecke/.conky/foilo/temp" &
