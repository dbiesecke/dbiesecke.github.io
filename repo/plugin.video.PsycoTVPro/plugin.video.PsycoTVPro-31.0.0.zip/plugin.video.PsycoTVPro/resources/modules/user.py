import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlBzeWNvVFZQcm8=')

name = b.b64decode('UHN5Y29UVg==')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('aHR0cDovL2xpdmUuZGFya3NpZGUtaXB0di5jb20=')
port = b.b64decode('ODA4MA==')
