# Wakanim plugin for Kodi

Wakanim a KODI (XBMC) plugin for Wakanim.tv.

Git repo: https://github.com/MrKrabat/plugin.video.wakanim

Forum posting: https://forum.kodi.tv/showthread.php?tid=322763

**WARNING: You MUST be a PREMIUM member OR buy videos to use this plugin!**
***

What this plugin currently can do:
- [x] Supports Wakanim France, Germany, Nordic and Russia
- [x] Login with your account
- [x] View last aired episodes
- [x] View last simulcasts
- [x] Search for animes
- [x] View "My Watchlist"
- [x] View "My Downloads"
- [x] View "My Collection"
- [x] View all available anime
- [x] View all seasons/arcs of an anime
- [x] View all episodes of an season/arc
- [x] Display various informations
- [x] Reactivate videos/streams
- [x] Watch videos you have bought
- [x] Watch videos with premium subscription
- [x] Watch anime trailer (requires YouTube plugin)
- [x] Synchronizes playback stats with Wakanim
***

_This website and addon is not affiliated with Wakanim._

_Kodi® (formerly known as XBMC™) is a registered trademark of the XBMC Foundation.
This website and addon is not affiliated with Kodi, Team Kodi, or the XBMC Foundation._