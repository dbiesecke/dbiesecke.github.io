"""
    Copyright (C) 2018, MuadDib
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    -------------------------------------------------------------
    Usage Examples:
	<dir>
<title>Amateur</title>
<cobp>category/amateur</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Anal</title>
<cobp>category/anal</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Asian</title>
<cobp>category/asian</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>BBC</title>
<cobp>category/bbc</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Big Ass</title>
<cobp>category/big-ass</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Big Dick</title>
<cobp>category/big-dick</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Big Tits</title>
<cobp>category/big-tits</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Blonde</title>
<cobp>category/blonde</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Blowjobs</title>
<cobp>category/blowjobs</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>British</title>
<cobp>category/british</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Brunette</title>
<cobp>category/brunette</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Cartoon</title>
<cobp>category/cartoon</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Casting</title>
<cobp>category/casting</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Couple</title>
<cobp>category/couple</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Cream Pie</title>
<cobp>category/cream-pie</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Cuckold</title>
<cobp>category/cuckold</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>
<dir>
<title>Cumshots</title>
<cobp>category/cumshots</cobp><thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Czech</title>
<cobp>category/czech</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Deep Throat</title>
<cobp>category/deep-throat</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Double Penetration</title>
<cobp>category/double-penetration</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Ebony</title>
<cobp>category/ebony</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Foot Fetish</title>
<cobp>category/foot-fetish</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Gang Bang</title>
<cobp>category/gang-bang</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>German</title>
<cobp>category/german</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>girlfriend</title>
<cobp>category/girlfriend</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Glamcore</title>
<cobp>category/glamcore</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Group Sex</title>
<cobp>category/group-sex</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Hairy</title>
<cobp>category/hairy</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Handjobs</title>
<cobp>category/handjobs</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Hardcore</title>
<cobp>category/hardcore</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>HD</title>
<cobp>category/hd</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Hentai</title>
<cobp>category/hentai</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Interracial</title>
<cobp>category/interracial</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Japanese</title>
<cobp>category/japanese</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Latin</title>
<cobp>category/latin</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Lesbian</title>
<cobp>category/lesbian</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Lingerie</title>
<cobp>category/lingerie</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Massage</title>
<cobp>category/massage</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Masturbation</title>
<cobp>category/masturbation</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Milf</title>
<cobp>category/milf</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Old and Young</title>
<cobp>category/old-and-young</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Orgasm</title>
<cobp>category/orgasm</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Orgy</title>
<cobp>category/orgy</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Parody</title>
<cobp>category/parody</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>POV</title>
<cobp>category/pov</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Public</title>
<cobp>category/public</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Redheads</title>
<cobp>category/redheads</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Russian</title>
<cobp>category/russian</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Schoolgirl</title>
<cobp>category/schoolgirl</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Spanish Porn</title>
<cobp>category/spanish-porn</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Squirting</title>
<cobp>category/squirting</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Tattoo</title>
<cobp>category/tattoo</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Teen</title>
<cobp>category/teen</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Threesome</title>
<cobp>category/threesome</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Toys</title>
<cobp>category/toys</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Uniform</title>
<cobp>category/uniform</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>

<dir>
<title>Webcams</title>
<cobp>category/webcams</cobp>
<thumbnail>https://imgur.com/phAgjMt.jpg</thumbnail>
<fanart>http://www.kinyu-z.net/data/wallpapers/218/1469323.jpg</fanart>
</dir>
	
<dir>
<title>Collection of Best Porn - Display Category content</title>
<cobp>category/squirting</sport_stream>
</dir>
"""

import requests,re,json,os,urlparse
import koding
import __builtin__
import xbmc,xbmcaddon,xbmcgui
from koding import route
from resources.lib.plugin import Plugin
from resources.lib.util import dom_parser
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from unidecode import unidecode

CACHE_TIME = 3600  # change to wanted cache time in seconds

addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'

class COBP(Plugin):
    name = "cobp"

    def process_item(self, item_xml):
        if "<cobp>" in item_xml:
            item = JenItem(item_xml)
            if "http" in item.get("cobp", ""):
                result_item = {
                    'label': item["title"],
                    'icon': item.get("thumbnail", addon_icon),
                    'fanart': item.get("fanart", addon_fanart),
                    'mode': "PlayVideo",
                    'url': item.get("cobp", ""),
                    'folder': False,
                    'imdb': "0",
                    'content': "files",
                    'season': "0",
                    'episode': "0",
                    'info': {},
                    'year': "0",
                    'context': get_context_items(item),
                    "summary": item.get("summary", None)
                }
            elif "category" in item.get("cobp", ""):
                result_item = {
                    'label': item["title"],
                    'icon': item.get("thumbnail", addon_icon),
                    'fanart': item.get("fanart", addon_fanart),
                    'mode': "COBP",
                    'url': item.get("cobp", ""),
                    'folder': True,
                    'imdb': "0",
                    'content': "files",
                    'season': "0",
                    'episode': "0",
                    'info': {},
                    'year': "0",
                    'context': get_context_items(item),
                    "summary": item.get("summary", None)
                }
            result_item["properties"] = {
                'fanart_image': result_item["fanart"]
            }
            result_item['fanart_small'] = result_item["fanart"]
            return result_item


@route(mode='COBP', args=["url"])
def get_stream(url):
    pins = ""
    xml = ""
    try:
        url = urlparse.urljoin('http://collectionofbestporn.com/', url)
        headers = {'User_Agent':User_Agent}
        html = requests.get(url,headers=headers).content
        vid_divs = dom_parser.parseDOM(html, 'div', attrs={'class':'video-item col-sm-5 col-md-4 col-xs-10'})
        count = 0
        for vid_section in vid_divs:
            thumb_div = dom_parser.parseDOM(vid_section, 'div', attrs={'class':'video-thumb'})[0]
            thumbnail = re.compile('<img src="(.+?)"',re.DOTALL).findall(str(thumb_div))[0]
            vid_page_url = re.compile('href="(.+?)"',re.DOTALL).findall(str(thumb_div))[0]

            title_div = dom_parser.parseDOM(vid_section, 'div', attrs={'class':'title'})[0]
            title = remove_non_ascii(re.compile('title="(.+?)"',re.DOTALL).findall(str(title_div))[0])
            count += 1

            xml += "<item>"\
                   "    <title>%s</title>"\
                   "    <thumbnail>%s</thumbnail>"\
                   "    <cobp>%s</cobp>"\
                   "    <summary>%s</summary>"\
                   "</item>" % (title,thumbnail,vid_page_url, title)

            if count == 24:
                pagination = dom_parser.parseDOM(html, 'li', attrs={'class':'next'})[0]
                next_page = dom_parser.parseDOM(pagination, 'a', ret='href')[0]
                xml += "<dir>"\
                       "    <title>Next Page</title>"\
                       "    <thumbnail>%s</thumbnail>"\
                       "    <cobp>%s</cobp>"\
                       "</dir>" % (addon_icon,next_page)
    except:
        pass
    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type(), pins)


@route(mode='PlayVideo', args=["url"])
def play_source(url):
    try:
        headers = {'User_Agent':User_Agent}
        vid_html = requests.get(url,headers=headers).content

        sources = dom_parser.parseDOM(vid_html, 'source', ret='src')
        vid_url = sources[len(sources)-1]

        xbmc.executebuiltin("PlayMedia(%s)" % vid_url)
    except:
        return

def remove_non_ascii(text):
    return unidecode(text)