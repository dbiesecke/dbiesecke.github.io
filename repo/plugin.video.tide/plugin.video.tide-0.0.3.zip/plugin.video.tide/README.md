## Tide
Sport events plugin for Kodi

## Disclaimer
Made purely for educational reasons. I take no responsibility whatsoever.

## Credits
Icon made by *Adib Sulthon*
