#!/bin/bash
FILE=plugin.video.animeanime
VERS=`cat addon.xml | egrep -o 'animeanime" version="[0-9\.]+[a-z]?' | sed -e 's/animeanime" version="//ig'`
rm *.zip $FILE
mkdir $FILE
cp -R ./* $FILE
zip -r ../$FILE-$VERS.zip ./$FILE
rm -fR $FILE
scp ../$FILE-$VERS.zip  ds-2:/volume1/web/repo/zips/$FILE-$VERS.zip
mv ../*.zip .
rsync -r ./* ds-2:/volume1/web/repo/plugin.video.animeanime
