import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmJ1Y2hjbHViMQo=')

name = b.b64decode('YnVjaGNsdWIK')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('bTN1Lmlib3hydS5jbHViCg==')
port = b.b64decode('MjU0NjEK')
