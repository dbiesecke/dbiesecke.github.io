from resources import service

service.run()
